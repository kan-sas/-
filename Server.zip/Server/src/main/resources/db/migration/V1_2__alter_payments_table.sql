ALTER TABLE payments
    DROP CONSTRAINT IF EXISTS fkivkqfvukcl61whatus8emcfcf;

ALTER TABLE payments
    DROP CONSTRAINT IF EXISTS fk_payments_approver;
ALTER TABLE payments
    ADD CONSTRAINT fk_payments_beneficiary
        FOREIGN KEY (beneficiary_id)
        REFERENCES users(id)
        ON DELETE SET NULL;

ALTER TABLE payments
    ADD CONSTRAINT fk_payments_approver
        FOREIGN KEY (approver_id)
        REFERENCES users(id)
        ON DELETE SET NULL;
CREATE INDEX idx_payments_beneficiary ON payments (beneficiary_id);
CREATE INDEX idx_payments_approver ON payments (approver_id);