package com.example.Server.beneficiary.exception;

import org.springframework.web.bind.annotation.RequestMapping;

public class InvalidPaymentException extends RuntimeException {
    public InvalidPaymentException(String message) {
        super(message);
    }
}
