package com.example.Server.beneficiary.mapper;

import com.example.Server.beneficiary.dto.response.ApproverInfo;
import com.example.Server.beneficiary.dto.response.BeneficiaryShortInfo;
import com.example.Server.beneficiary.dto.response.PaymentResponse;
import com.example.Server.beneficiary.entity.PaymentEntity;
import com.example.Server.beneficiary.dto.PaymentTypeEnum;
import com.example.Server.user.entity.UserEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import java.math.BigDecimal;

@Mapper(componentModel = "spring", imports = {BigDecimal.class})
public interface PaymentMapper {

    @Mapping(source = "beneficiary", target = "beneficiary", qualifiedByName = "mapBeneficiary")
    @Mapping(source = "approver", target = "approver", qualifiedByName = "mapApprover")
    @Mapping(source = "type", target = "type")
    @Mapping(source = "status", target = "status")
    PaymentResponse toResponse(PaymentEntity payment);

    @Named("mapBeneficiary")
    default BeneficiaryShortInfo mapBeneficiary(UserEntity beneficiary) {
        if (beneficiary == null) return null;

        return new BeneficiaryShortInfo(
                beneficiary.getId(),
                beneficiary.getFirstName(),
                beneficiary.getLastName()
        );
    }

    @Named("mapApprover")
    default ApproverInfo mapApprover(UserEntity approver) {
        if (approver == null) return null;

        return new ApproverInfo(
                approver.getId(),
                approver.getFirstName(),
                approver.getLastName()
        );
    }

    default String mapPaymentType(PaymentTypeEnum type) {
        return type != null ? type.name() : null;
    }

    default PaymentTypeEnum mapPaymentType(String type) {
        return type != null ? PaymentTypeEnum.valueOf(type) : null;
    }

    default BigDecimal mapAmount(String amount) {
        return amount != null ? new BigDecimal(amount) : null;
    }

    default String mapAmount(BigDecimal amount) {
        return amount != null ? amount.toPlainString() : null;
    }
}