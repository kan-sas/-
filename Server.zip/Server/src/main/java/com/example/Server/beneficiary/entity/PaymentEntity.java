package com.example.Server.beneficiary.entity;

import com.example.Server.beneficiary.dto.PaymentStatusEnum;
import com.example.Server.beneficiary.dto.PaymentTypeEnum;
import com.example.Server.user.entity.UserEntity;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "payments")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class PaymentEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Enumerated(EnumType.STRING)
    private PaymentStatusEnum status = PaymentStatusEnum.PENDING;

    @ManyToOne(fetch = FetchType.LAZY, optional = true) // Изменено на optional = true
    @JoinColumn(name = "beneficiary_id")
    private UserEntity beneficiary;

    @ManyToOne(fetch = FetchType.LAZY, optional = true) // Изменено на optional = true
    @JoinColumn(name = "approver_id")
    private UserEntity approver;

    @Column(name = "approval_date")
    private LocalDate approvalDate;

    @Enumerated(EnumType.STRING)
    private PaymentTypeEnum type; // Заменяем SubjectEntity на enum

    private BigDecimal amount; // Заменяем value (оценку) на сумму выплаты
    private LocalDate date;
    private String department; // Отдел, осуществляющий выплату
    private String comment;

}