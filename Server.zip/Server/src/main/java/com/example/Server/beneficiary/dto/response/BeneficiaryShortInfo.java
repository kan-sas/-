package com.example.Server.beneficiary.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class BeneficiaryShortInfo {
    private Long id;
    private String firstName;
    private String lastName;
}
