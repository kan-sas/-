package com.example.Server.social_worker.service;

import com.example.Server.beneficiary.dto.PaymentStatusEnum;
import com.example.Server.beneficiary.dto.response.PaymentResponse;
import com.example.Server.beneficiary.entity.PaymentEntity;
import com.example.Server.beneficiary.exception.InvalidPaymentException;
import com.example.Server.beneficiary.mapper.PaymentMapper;
import com.example.Server.beneficiary.repository.PaymentRepository;
import com.example.Server.social_worker.dto.request.PaymentStatusUpdateRequest;
import com.example.Server.user.entity.UserEntity;
import com.example.Server.user.exception.EntityNotFoundException;
import com.example.Server.user.exception.UnauthorizedAccessException;
import com.example.Server.user.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class SocialWorkerPaymentService {
    private static final Logger logger = LoggerFactory.getLogger(SocialWorkerPaymentService.class);

    private static final List<PaymentStatusEnum> ALLOWED_STATUSES = List.of(
            PaymentStatusEnum.APPROVED,
            PaymentStatusEnum.REJECTED
    );

    private final PaymentRepository paymentRepository;
    private final UserRepository userRepository;
    private final PaymentMapper paymentMapper;

    @Transactional
    public PaymentResponse updatePaymentStatus(Long paymentId, PaymentStatusUpdateRequest request) {
        PaymentEntity payment = findPaymentById(paymentId);
        UserEntity socialWorker = validateSocialWorker(request.getSocialWorkerId());
        validateStatusTransition(payment.getStatus(), request.getStatus());

        payment.setStatus(request.getStatus());
        payment.setApprover(socialWorker);

        // Автоматическая установка даты подтверждения
        if(request.getStatus() == PaymentStatusEnum.APPROVED) {
            payment.setApprovalDate(LocalDate.now());
            logger.debug("Установлена дата подтверждения для выплаты {}: {}",
                    paymentId, LocalDate.now());
        } else {
            payment.setApprovalDate(null);
        }

        logger.info("Payment {} status updated to {} by social worker {}",
                paymentId, request.getStatus(), socialWorker.getId());

        return paymentMapper.toResponse(paymentRepository.save(payment));
    }

    @Transactional(readOnly = true)
    public List<PaymentResponse> getPendingPayments() {
        return mapToResponse(paymentRepository.findByStatus(PaymentStatusEnum.PENDING));
    }

    @Transactional(readOnly = true)
    public List<PaymentResponse> getApprovedPayments(LocalDate startDate, LocalDate endDate) {
        return mapToResponse(paymentRepository.findApprovedBetweenDates(startDate, endDate));
    }

    private void handleApproval(PaymentEntity payment) {
        payment.setApprovalDate(LocalDate.now());
        // Комментарий больше не очищается автоматически
    }

    private void handleRejection(PaymentEntity payment) {
        payment.setApprovalDate(null);
        // Убрали проверку и установку комментария
    }

    private void validateStatusTransition(PaymentStatusEnum currentStatus,
                                          PaymentStatusEnum newStatus) {
        if(currentStatus != PaymentStatusEnum.PENDING) {
            throw new InvalidPaymentException(
                    "Статус можно менять только для выплат в статусе PENDING. Текущий статус: " + currentStatus
            );
        }

        if(!ALLOWED_STATUSES.contains(newStatus)) {
            throw new InvalidPaymentException(
                    "Недопустимый целевой статус: " + newStatus + ". Разрешено: " + ALLOWED_STATUSES
            );
        }
    }

    // Остальные вспомогательные методы без изменений
    private PaymentEntity findPaymentById(Long id) {
        return paymentRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Выплата не найдена"));
    }

    private UserEntity validateSocialWorker(Long userId) {
        if (!userRepository.existsByIdAndRole(userId, UserEntity.Role.SOCIAL_WORKER)) {
            throw new UnauthorizedAccessException("Нет прав для изменения статуса выплаты");
        }
        return userRepository.findById(userId)
                .orElseThrow(() -> new EntityNotFoundException("Пользователь не найден"));
    }

    private List<PaymentResponse> mapToResponse(List<PaymentEntity> payments) {
        return payments.stream()
                .map(paymentMapper::toResponse)
                .collect(Collectors.toList());
    }
}