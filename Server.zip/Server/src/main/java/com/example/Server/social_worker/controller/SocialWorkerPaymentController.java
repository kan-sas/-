package com.example.Server.social_worker.controller;

import com.example.Server.beneficiary.dto.response.PaymentResponse;
import com.example.Server.social_worker.dto.request.PaymentStatusUpdateRequest;
import com.example.Server.social_worker.service.SocialWorkerPaymentService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/payments")
@RequiredArgsConstructor
public class SocialWorkerPaymentController {

    private final SocialWorkerPaymentService paymentService;

    @PutMapping("/{paymentId}/status")
    public PaymentResponse updatePaymentStatus(
            @PathVariable Long paymentId,
            @RequestBody @Valid PaymentStatusUpdateRequest request) {
        return paymentService.updatePaymentStatus(paymentId, request);
    }

    @GetMapping("/pending")
    public List<PaymentResponse> getPendingPayments() {
        return paymentService.getPendingPayments();
    }

    @GetMapping("/approved")
    public List<PaymentResponse> getApprovedPayments(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) {
        return paymentService.getApprovedPayments(startDate, endDate);
    }
}