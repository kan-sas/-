package com.example.Server.beneficiary.dto;

public enum PaymentTypeEnum {
    PENSION,          // Пенсия
    ALLOWANCE,        // Пособие
    SUBSIDY,          // Субсидия
    ONE_TIME_PAYMENT, // Единовременная выплата
    OTHER
}
