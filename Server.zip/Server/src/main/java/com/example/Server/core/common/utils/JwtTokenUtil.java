package com.example.Server.core.common.utils;

import com.example.Server.core.common.security.CustomUserDetails;
import com.example.Server.user.entity.UserEntity;
import com.example.Server.user.repository.UserRepository;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import java.security.Key;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * Утилитный класс для генерации и валидации JWT.
 * При генерации кладёт клеймы:
 * - role
 * - user_id (либо из CustomUserDetails, либо из БД по username)
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class JwtTokenUtil {

    @Value("${jwt.secret}")
    private String secret;

    @Value("${jwt.expiration}")
    private long expiration; // в секундах

    private final UserRepository userRepository;

    /**
     * Собирает клеймы и создаёт токен.
     */
    public String generateToken(UserDetails userDetails) {
        Map<String, Object> claims = new HashMap<>();

        // Пишем роль, если она есть
        userDetails.getAuthorities().stream()
                .findFirst()
                .map(a -> a.getAuthority())
                .ifPresent(r -> claims.put("role", r));

        // Определяем ID пользователя
        Long userId = resolveUserId(userDetails);
        claims.put("user_id", userId);

        log.info("Generating JWT for {} (id={})", userDetails.getUsername(), userId);
        log.debug("JWT claims: {}", claims);

        return Jwts.builder()
                .setClaims(claims)
                .setSubject(userDetails.getUsername())
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + expiration * 1000))
                .signWith(getSigningKey(), SignatureAlgorithm.HS256)
                .compact();
    }

    /**
     * Если в principal ваш CustomUserDetails — берём из него ID,
     * иначе подгружаем сущность из БД по username.
     */
    private Long resolveUserId(UserDetails userDetails) {
        if (userDetails instanceof CustomUserDetails custom) {
            return custom.getId();
        }
        String username = userDetails.getUsername();
        UserEntity entity = userRepository.findByUsername(username)
                .orElseThrow(() -> {
                    log.error("User not found in DB: {}", username);
                    return new IllegalStateException("User not found: " + username);
                });
        return entity.getId();
    }

    /**
     * Проверяет, что токен не просрочен.
     */
    public boolean validateToken(String token) {
        try {
            return !isTokenExpired(token);
        } catch (Exception e) {
            log.warn("Token validation error: {}", e.getMessage());
            return false;
        }
    }

    /**
     * Извлекает username из токена.
     */
    public String extractUsername(String token) {
        return extractClaim(token, Claims::getSubject);
    }

    /**
     * Извлекает user_id из токена.
     */
    public Long extractUserId(String token) {
        return extractClaim(token, claims -> claims.get("user_id", Long.class));
    }

    /**
     * Внутренний метод для извлечения любого клейма.
     */
    private <T> T extractClaim(String token, java.util.function.Function<Claims, T> resolver) {
        Claims claims = Jwts.parser()
                .setSigningKey(getSigningKey())
                .build()
                .parseClaimsJws(token)
                .getBody();
        return resolver.apply(claims);
    }

    /**
     * Проверяет дату истечения.
     */
    private boolean isTokenExpired(String token) {
        Date expirationDate = extractClaim(token, Claims::getExpiration);
        return expirationDate.before(new Date());
    }

    /**
     * Декодирует секрет и возвращает ключ для подписи.
     */
    private Key getSigningKey() {
        byte[] keyBytes = Decoders.BASE64.decode(secret);
        return Keys.hmacShaKeyFor(keyBytes);
    }
}
