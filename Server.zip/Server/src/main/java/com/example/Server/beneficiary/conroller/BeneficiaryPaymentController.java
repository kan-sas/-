package com.example.Server.beneficiary.conroller;

import com.example.Server.beneficiary.dto.request.PaymentRequest;
import com.example.Server.beneficiary.dto.response.PaymentResponse;
import com.example.Server.beneficiary.service.BeneficiaryPaymentService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/payments")
@RequiredArgsConstructor
public class BeneficiaryPaymentController {

    private final BeneficiaryPaymentService paymentService;

    /**
     * Создать новую выплату
     */
    @PostMapping
    public ResponseEntity<PaymentResponse> createPayment(
            @Valid @RequestBody PaymentRequest request) {
        PaymentResponse response = paymentService.createPayment(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    /**
     * Получить выплату по её ID
     */
    @GetMapping("/{id}")
    public ResponseEntity<PaymentResponse> getPaymentById(@PathVariable Long id) {
        return ResponseEntity.ok(paymentService.getPaymentById(id));
    }

    /**
     * Получить все выплаты данного бенефициара (с фильтрацией по статусу и другим критериям)
     */
    @GetMapping("/beneficiary/{beneficiaryId}")
    public ResponseEntity<List<PaymentResponse>> getPaymentsByBeneficiary(
            @PathVariable Long beneficiaryId) {
        return ResponseEntity.ok(paymentService.getPaymentsByBeneficiary(beneficiaryId));
    }

    /**
     * Получить полный список выплат бенефициара без фильтрации
     */
    @GetMapping("/beneficiary/{beneficiaryId}/all")
    public ResponseEntity<List<PaymentResponse>> getAllPaymentsByBeneficiary(
            @PathVariable Long beneficiaryId) {
        return ResponseEntity.ok(paymentService.getAllPaymentsByBeneficiary(beneficiaryId));
    }

    /**
     * Обновить существующую выплату по ID
     */
    @PatchMapping("/{id}")
    public ResponseEntity<PaymentResponse> updatePayment(
            @PathVariable Long id,
            @Valid @RequestBody PaymentRequest request) {
        PaymentResponse response = paymentService.updatePayment(id, request);
        return ResponseEntity.ok(response);
    }

    /**
     * Удалить выплату по ID
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePayment(
            @PathVariable Long id) {
        paymentService.deletePayment(id);
        return ResponseEntity.noContent().build();
    }
}
