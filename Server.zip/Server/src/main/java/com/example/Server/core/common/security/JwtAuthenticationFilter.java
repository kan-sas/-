package com.example.Server.core.common.security;

import com.example.Server.core.common.utils.JwtTokenUtil;
import com.example.Server.user.service.CustomUserDetailsService;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.Optional;
import java.util.Set;

@Slf4j
@Component
@RequiredArgsConstructor
public class JwtAuthenticationFilter extends OncePerRequestFilter {

    private static final Set<String> PUBLIC_PATHS = Set.of(
            "/public/auth/login",
            "/public/auth/register"
    );

    private final CustomUserDetailsService customUserDetailsService;
    private final JwtTokenUtil jwtTokenUtil;

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain chain) throws ServletException, IOException {
        log.debug("🔍 Starting authentication for: {} {}", request.getMethod(), request.getRequestURI());

        // Пропуск OPTIONS-запросов
        if ("OPTIONS".equalsIgnoreCase(request.getMethod())) {
            log.trace("🔄 Bypassing OPTIONS request");
            chain.doFilter(request, response);
            return;
        }

        final String requestUri = request.getRequestURI();

        // Проверка публичных путей
        if (isPublicPath(requestUri)) {
            log.info("📭 Public endpoint access: {}", requestUri);
            chain.doFilter(request, response);
            return;
        }

        try {
            // Извлечение токена
            final String token = extractJwtFromRequest(request)
                    .orElseThrow(() -> {
                        log.warn("🚫 Missing Authorization header");
                        return new SecurityException("Authorization header is required");
                    });
            log.debug("🪙 Token found (truncated): {}...", token.substring(0, Math.min(15, token.length())));

            // Валидация токена
            if (!validateToken(token)) {
                log.warn("❌ Token validation failed");
                sendError(response, HttpStatus.UNAUTHORIZED, "Invalid token");
                return;
            }

            // Аутентификация
            authenticate(token);
            log.info("✅ Authenticated user for: {}", requestUri);
            chain.doFilter(request, response);

        } catch (SecurityException e) {
            log.warn("🚨 Security error: {}", e.getMessage());
            sendError(response, HttpStatus.UNAUTHORIZED, e.getMessage());
        } catch (UsernameNotFoundException e) {
            log.error("👤 User not found: {}", e.getMessage());
            sendError(response, HttpStatus.FORBIDDEN, "User not found");
        } catch (Exception e) {
            log.error("💥 Critical authentication error", e);
            sendError(response, HttpStatus.INTERNAL_SERVER_ERROR, "Internal server error");
        }
    }

    private boolean validateToken(String token) {
        try {
            boolean isValid = jwtTokenUtil.validateToken(token);
            log.debug("🛡️ Token validation result: {}", isValid ? "VALID" : "INVALID");
            return isValid;
        } catch (Exception e) {
            log.warn("⚠️ Token validation exception: {}", e.getMessage());
            return false;
        }
    }

    private void authenticate(String token) {
        final String username = jwtTokenUtil.extractUsername(token);
        log.debug("👤 Extracted username from token: {}", username);

        final UserDetails userDetails = customUserDetailsService.loadUserByUsername(username);
        log.debug("🔑 User authorities: {}", userDetails.getAuthorities());

        if (!jwtTokenUtil.validateToken(token)) {
            log.warn("🔐 Token-user mismatch for: {}", username);
            throw new SecurityException("Token validation failed");
        }

        final var authentication = new UsernamePasswordAuthenticationToken(
                userDetails,
                null,
                userDetails.getAuthorities()
        );

        SecurityContextHolder.getContext().setAuthentication(authentication);
        log.debug("🔒 Security context updated for: {}", username);
    }

    private boolean isPublicPath(String uri) {
        boolean isPublic = PUBLIC_PATHS.stream().anyMatch(path ->
                path.equalsIgnoreCase(uri) || uri.startsWith(path + "/")
        );
        log.trace("🌐 Public path check [{}]: {}", uri, isPublic ? "PUBLIC" : "PRIVATE");
        return isPublic;
    }

    private Optional<String> extractJwtFromRequest(HttpServletRequest request) {
        return Optional.ofNullable(request.getHeader("Authorization"))
                .filter(header -> header.startsWith("Bearer "))
                .map(header -> {
                    String token = header.substring(7);
                    log.trace("🔑 Raw token header: {}", header);
                    return token;
                });
    }

    private void sendError(HttpServletResponse response,
                           HttpStatus status,
                           String message) throws IOException {
        log.warn("⚡ Returning error: {} {}", status.value(), message);
        response.setStatus(status.value());
        response.setContentType("application/json");
        response.getWriter().write(
                String.format("{\"error\": \"%s\", \"message\": \"%s\"}",
                        status.getReasonPhrase(), message)
        );
        response.getWriter().flush();
    }
}