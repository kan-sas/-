package com.example.Server.user.dto.request;

import lombok.Data;

@Data
public class UpdateProfileRequest {
    private String currentPassword; // Только для смены пароля
    private String newPassword;
    private String email;
    private String phoneNumber;
}