package com.example.Server.beneficiary.dto.request;

import com.example.Server.beneficiary.dto.PaymentStatusEnum;
import com.example.Server.beneficiary.dto.PaymentTypeEnum;
import com.example.Server.beneficiary.entity.PaymentEntity;
import com.example.Server.core.common.validation.EnumValue;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Data;

@Data
public class PaymentRequest {
    @NotNull(message = "ID получателя обязательно")
    private Long beneficiaryId;

    @NotBlank(message = "Тип выплаты обязателен")
    @EnumValue(
            enumClass = PaymentTypeEnum.class,
            message = "Недопустимый тип выплаты"
    )
    private String type;
    @NotNull(message = "Сумма обязательна")
    @Positive(message = "Сумма должна быть положительной")
    private String amount; // Строка для точного представления BigDecimal

    private String department; // Отдел, осуществляющий выплату
    private String comment;
}