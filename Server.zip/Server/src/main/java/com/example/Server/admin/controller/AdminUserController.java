package com.example.Server.admin.controller;

import com.example.Server.admin.dto.request.ChangeRoleRequest;
import com.example.Server.admin.service.AdminUserService;
import com.example.Server.core.common.dto.ProfileResponse;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/admin/users")
@PreAuthorize("hasAuthority('ADMIN')")
@RequiredArgsConstructor
public class AdminUserController {

    private static final Logger logger = LoggerFactory.getLogger(AdminUserController.class);
    private final AdminUserService adminUserService;

    @GetMapping("/getall")
    public ResponseEntity<List<ProfileResponse>> getAllUsers() {
        logger.info("Получение списка всех пользователей");
        List<ProfileResponse> users = adminUserService.getAllUsers();
        logger.info("Успешно получено {} пользователей", users.size());
        return ResponseEntity.ok(users);
    }

    @GetMapping("/{userId}")
    public ResponseEntity<ProfileResponse> getUserById(@PathVariable Long userId) {
        logger.info("Запрос пользователя с ID: {}", userId);
        ProfileResponse user = adminUserService.getUserById(userId);
        logger.info("Пользователь с ID {} найден", userId);
        return ResponseEntity.ok(user);
    }

    @PatchMapping("/{userId}/role")
    public ResponseEntity<ProfileResponse> changeUserRole(
            @PathVariable Long userId,
            @RequestBody ChangeRoleRequest request) {
        logger.info("Смена роли пользователя {} на {}", userId, request.getNewRole());
        ProfileResponse updatedUser = adminUserService.changeUserRole(userId, request);
        logger.info("Роль пользователя {} изменена на {}", userId, updatedUser.getRole());
        return ResponseEntity.ok(updatedUser);
    }

    @DeleteMapping("/{userId}")
    public ResponseEntity<Void> deleteUser(@PathVariable Long userId) {
        logger.info("Удаление пользователя {}", userId);
        adminUserService.deleteUser(userId);
        logger.info("Пользователь {} удален", userId);
        return ResponseEntity.noContent().build();
    }
}