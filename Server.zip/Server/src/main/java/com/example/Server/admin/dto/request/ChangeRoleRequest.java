package com.example.Server.admin.dto.request;

import com.example.Server.user.entity.UserEntity;
import lombok.Data;
import lombok.Getter;

@Data
@Getter
public class ChangeRoleRequest {
    private UserEntity.Role newRole;
}
