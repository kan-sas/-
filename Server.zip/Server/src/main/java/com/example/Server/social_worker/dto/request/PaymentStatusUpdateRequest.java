package com.example.Server.social_worker.dto.request;

import com.example.Server.beneficiary.dto.PaymentStatusEnum;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class PaymentStatusUpdateRequest {
    @NotNull(message = "Статус обязателен")
    private PaymentStatusEnum status;

    @NotNull(message = "ID социального работника обязательно")
    private Long socialWorkerId;
}
