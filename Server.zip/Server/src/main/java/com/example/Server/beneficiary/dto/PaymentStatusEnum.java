package com.example.Server.beneficiary.dto;

public enum PaymentStatusEnum {
    PENDING,    // На рассмотрении
    APPROVED,   // Подтверждена
    REJECTED,   // Отклонена
    COMPLETED
}
