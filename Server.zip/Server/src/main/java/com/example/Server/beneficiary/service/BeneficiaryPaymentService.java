package com.example.Server.beneficiary.service;

import com.example.Server.beneficiary.dto.PaymentStatusEnum;
import com.example.Server.beneficiary.dto.PaymentTypeEnum;
import com.example.Server.beneficiary.dto.request.PaymentRequest;
import com.example.Server.beneficiary.dto.response.PaymentResponse;
import com.example.Server.beneficiary.entity.PaymentEntity;
import com.example.Server.beneficiary.exception.InvalidPaymentException;
import com.example.Server.user.exception.EntityNotFoundException;
import com.example.Server.beneficiary.mapper.PaymentMapper;
import com.example.Server.beneficiary.repository.PaymentRepository;
import com.example.Server.user.entity.UserEntity;
import com.example.Server.user.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class BeneficiaryPaymentService {
    private static final Logger logger = LoggerFactory.getLogger(BeneficiaryPaymentService.class);

    private final PaymentRepository paymentRepository;
    private final UserRepository userRepository;
    private final PaymentMapper paymentMapper;

    @Transactional(readOnly = true)
    public List<PaymentResponse> getAllPaymentsByBeneficiary(Long beneficiaryId) {
        validateBeneficiaryExists(beneficiaryId);
        return mapToResponse(paymentRepository.findAllByBeneficiaryId(beneficiaryId));
    }
    @Transactional
    public PaymentResponse createPayment(PaymentRequest request) {
        validatePaymentRequest(request);
        UserEntity beneficiary = getUserEntity(request.getBeneficiaryId());

        PaymentEntity payment = buildPaymentEntity(request, beneficiary);
        return paymentMapper.toResponse(paymentRepository.save(payment));
    }

    @Transactional(readOnly = true)
    public PaymentResponse getPaymentById(Long id) {
        return paymentMapper.toResponse(findPaymentById(id));
    }

    @Transactional(readOnly = true)
    public List<PaymentResponse> getPaymentsByBeneficiary(Long beneficiaryId) {
        validateBeneficiaryExists(beneficiaryId);
        return mapToResponse(paymentRepository.findByBeneficiaryId(beneficiaryId));
    }

    @Transactional
    public PaymentResponse updatePayment(Long paymentId, PaymentRequest request) {
        PaymentEntity payment = findPaymentById(paymentId);
        updatePaymentEntity(payment, request);
        return paymentMapper.toResponse(paymentRepository.save(payment));
    }

    @Transactional
    public void deletePayment(Long id) {
        if (!paymentRepository.existsById(id)) {
            throw new EntityNotFoundException("Выплата не найдена");
        }
        paymentRepository.deleteById(id);
    }

    // Вспомогательные методы
    private PaymentEntity findPaymentById(Long id) {
        return paymentRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Выплата не найдена"));
    }

    private void validatePaymentRequest(PaymentRequest request) {
        logger.debug("Валидация запроса выплаты: {}", request);

        if (request.getBeneficiaryId() == null) {
            logger.error("Отсутствует ID получателя в запросе");
            throw new IllegalArgumentException("ID получателя обязательно");
        }

        if (request.getAmount() == null || new BigDecimal(request.getAmount()).compareTo(BigDecimal.ZERO) <= 0) {
            logger.error("Некорректная сумма выплаты: {}", request.getAmount());
            throw new InvalidPaymentException("Сумма выплаты должна быть положительной");
        }

        try {
            PaymentTypeEnum.valueOf(request.getType());
        } catch (IllegalArgumentException e) {
            logger.error("Неверный тип выплаты: {}", request.getType());
            throw new InvalidPaymentException("Неверный тип выплаты");
        }
    }

    private PaymentEntity buildPaymentEntity(PaymentRequest request, UserEntity beneficiary) {
        PaymentEntity payment = new PaymentEntity();
        payment.setBeneficiary(beneficiary);
        payment.setType(PaymentTypeEnum.valueOf(request.getType()));
        payment.setAmount(new BigDecimal(request.getAmount()));
        payment.setDate(LocalDate.now());
        payment.setDepartment(request.getDepartment());
        payment.setComment(request.getComment());
        payment.setStatus(PaymentStatusEnum.PENDING);
        return payment;
    }

    private void updatePaymentEntity(PaymentEntity payment, PaymentRequest request) {
        if (request.getType() != null) {
            payment.setType(PaymentTypeEnum.valueOf(request.getType()));
        }
        if (request.getAmount() != null) {
            payment.setAmount(new BigDecimal(request.getAmount()));
        }
        if (request.getDepartment() != null) {
            payment.setDepartment(request.getDepartment());
        }
        if (request.getComment() != null) {
            payment.setComment(request.getComment());
        }
    }

    private UserEntity getUserEntity(Long beneficiaryId) {
        return userRepository.findById(beneficiaryId)
                .orElseThrow(() -> new EntityNotFoundException("Получатель не найден"));
    }
    private void validateBeneficiaryExists(Long beneficiaryId) {
        if (!userRepository.existsById(beneficiaryId)) {
            logger.error("Получатель не найден: ID {}", beneficiaryId);
            throw new EntityNotFoundException("Получатель не найден");
        }
    }

    // Добавляем недостающий метод mapToResponse
    private List<PaymentResponse> mapToResponse(List<PaymentEntity> payments) {
        return payments.stream()
                .map(paymentMapper::toResponse)
                .collect(Collectors.toList());
    }
}

