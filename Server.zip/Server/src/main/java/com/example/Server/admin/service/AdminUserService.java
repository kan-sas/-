package com.example.Server.admin.service;

import com.example.Server.admin.dto.request.ChangeRoleRequest;
import com.example.Server.core.common.dto.ProfileResponse;
import com.example.Server.user.entity.UserEntity;
import com.example.Server.user.mapper.UserMapper;
import com.example.Server.user.repository.UserRepository;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class AdminUserService {
    private static final Logger logger = LoggerFactory.getLogger(AdminUserService.class);
    private final UserRepository userRepository;
    private final UserMapper userMapper;

    @PreAuthorize("hasAuthority('ADMIN')")
    public List<ProfileResponse> getAllUsers() {
        logger.info("Запрос на получение всех пользователей");
        return userRepository.findAll().stream()
                .map(userMapper::toProfileResponse)
                .peek(user -> logger.debug("Найден пользователь: {}", user.getUsername()))
                .toList();
    }

    @PreAuthorize("hasAuthority('ADMIN')")
    public ProfileResponse getUserById(Long id) {
        logger.info("Запрос пользователя по ID: {}", id);
        return userRepository.findById(id)
                .map(userMapper::toProfileResponse)
                .orElseThrow(() -> {
                    logger.error("Пользователь с ID {} не найден", id);
                    return new EntityNotFoundException("Пользователь не найден");
                });
    }

    @PreAuthorize("hasAuthority('ADMIN')")
    @Transactional
    public ProfileResponse changeUserRole(Long userId, ChangeRoleRequest request) {
        logger.info("Изменение роли пользователя {} на {}", userId, request.getNewRole());
        UserEntity user = getUserEntity(userId);

        user.setRole(request.getNewRole());
        UserEntity savedUser = userRepository.save(user);
        logger.info("Роль успешно изменена");

        return userMapper.toProfileResponse(savedUser);
    }

    // AdminUserService.java
    @PreAuthorize("hasAuthority('ADMIN')")
    @Transactional
    public void deleteUser(Long userId) {
        logger.info("Удаление пользователя {}", userId);
        UserEntity user = getUserEntity(userId);
        checkSelfDeletion(user);
        checkAdminDeletion(user);

        userRepository.delete(user); // Каскадная обработка NULL выполнится в БД
        logger.info("Пользователь {} удален", user.getUsername());
    }

    private UserEntity getUserEntity(Long userId) {
        return userRepository.findById(userId)
                .orElseThrow(() -> new EntityNotFoundException("Пользователь не найден"));
    }

    private void checkSelfDeletion(UserEntity user) {
        String currentUsername = SecurityContextHolder.getContext().getAuthentication().getName();
        if (user.getUsername().equals(currentUsername)) {
            logger.error("Попытка самоудаления администратора");
            throw new SecurityException("Самоудаление запрещено");
        }
    }

    private void checkAdminDeletion(UserEntity user) {
        if (user.getRole().equals(UserEntity.Role.ADMIN)) {
            logger.error("Попытка удаления администратора");
            throw new SecurityException("Удаление администраторов запрещено");
        }
    }
}