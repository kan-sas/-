package com.example.Server.beneficiary.dto.response;

import com.example.Server.beneficiary.dto.PaymentStatusEnum;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
public class PaymentResponse {
    private Long id;
    private BeneficiaryShortInfo beneficiary; // Вложенный DTO вместо отдельных полей
    private String type;
    private BigDecimal amount;
    private LocalDate date;
    private String department;
    private String comment;
    private PaymentStatusEnum status; // Enum вместо boolean
    private ApproverInfo approver; // Кто подтвердил (если approved)

}