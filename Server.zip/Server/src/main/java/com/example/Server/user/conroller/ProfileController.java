package com.example.Server.user.conroller;

import com.example.Server.core.common.dto.ProfileResponse;
import com.example.Server.user.dto.request.UpdateProfileRequest;
import com.example.Server.user.service.ProfileService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/user/profile")
@RequiredArgsConstructor
public class ProfileController {

    private final ProfileService profileService;

    @GetMapping
    public ResponseEntity<ProfileResponse> getProfile(@AuthenticationPrincipal UserDetails userDetails) {
        return ResponseEntity.ok(profileService.getProfile(userDetails.getUsername()));
    }

    @DeleteMapping
    public ResponseEntity<Void> deleteProfile(@AuthenticationPrincipal UserDetails userDetails) {
        profileService.deleteProfile(userDetails.getUsername());
        return ResponseEntity.noContent().build();
    }

    @PatchMapping("/password")
    public ResponseEntity<Void> updatePassword(
            @AuthenticationPrincipal UserDetails userDetails,
            @RequestBody UpdateProfileRequest request) {
        profileService.updatePassword(
                userDetails.getUsername(),
                request.getCurrentPassword(), // Требуем текущий пароль
                request.getNewPassword());
        return ResponseEntity.ok().build();
    }

    @PatchMapping("/contact")
    public ResponseEntity<Void> updateContactInfo(
            @AuthenticationPrincipal UserDetails userDetails,
            @RequestBody UpdateProfileRequest request) {
        profileService.updateContactInfo(
                userDetails.getUsername(),
                request.getEmail(),
                request.getPhoneNumber());
        return ResponseEntity.ok().build();
    }

}