package com.example.Server.beneficiary.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ApproverInfo {
    private Long id;
    private String firstName;
    private String lastName;

    // Опционально: метод для полного имени
    public String getFullName() {
        return String.format("%s %s", firstName, lastName).trim();
    }
}

