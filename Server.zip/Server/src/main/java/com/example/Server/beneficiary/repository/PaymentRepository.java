package com.example.Server.beneficiary.repository;

import com.example.Server.beneficiary.dto.PaymentStatusEnum;
import com.example.Server.beneficiary.dto.PaymentTypeEnum;
import com.example.Server.beneficiary.entity.PaymentEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface PaymentRepository extends JpaRepository<PaymentEntity, Long> {
    // Для BeneficiaryPaymentService
    List<PaymentEntity> findByBeneficiaryId(Long beneficiaryId);
    List<PaymentEntity> findAllByBeneficiaryId(Long beneficiaryId);
    // Для SocialWorkerPaymentService
    List<PaymentEntity> findByStatus(PaymentStatusEnum status);

    @Query("SELECT p FROM PaymentEntity p WHERE p.status = 'APPROVED' AND p.approvalDate BETWEEN :start AND :end")
    List<PaymentEntity> findApprovedBetweenDates(@Param("start") LocalDate start,
                                                 @Param("end") LocalDate end);
}